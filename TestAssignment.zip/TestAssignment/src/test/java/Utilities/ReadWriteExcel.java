package Utilities;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ReadWriteExcel
{
    File file=new File("");
    FileInputStream input=new FileInputStream(file);
    XSSFWorkbook workbook =new XSSFWorkbook(input);
    XSSFSheet sheet= workbook.getSheet("sheet1");

    public ReadWriteExcel(XSSFSheet sheet) throws IOException
    {
        sheet=this.sheet;
    }

    public String getValue(int i, int j)
    {
        return sheet.getRow(i).getCell(j).getStringCellValue();
    }
}
