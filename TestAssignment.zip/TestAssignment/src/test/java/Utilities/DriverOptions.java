package Utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public enum DriverOptions implements Utilities.DriverSetup
{
    CHROME {
        public WebDriver getWebDriverObject(DesiredCapabilities capabilities)
        {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--incognito");
            options.addArguments("--force-device-scale-factor=1.1");
            options.addArguments("--start-maximized");
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-gpu");
            options.addArguments("--no-default-browser-check");
            options.addArguments("--disable-dev-shm-usage");
            options.addArguments("--disable-web-security");
            options.addArguments("--proxy-server='direct://'");
            options.addArguments("--proxy-bypass-list=*");
            options.addArguments("--headless");
            options.addArguments("--test-type");
            options.addArguments("--no-first-run");
            options.addArguments("--disable-extensions");
            options.merge(capabilities);

            return new ChromeDriver(options);
        }
    };

    public final static boolean HEADLESS = Boolean.getBoolean ("headless");
}