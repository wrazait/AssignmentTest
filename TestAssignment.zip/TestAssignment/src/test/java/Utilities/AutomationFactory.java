package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import static Utilities.DriverOptions.CHROME;

public class AutomationFactory
{
    private WebDriver webDriver;
    private DriverOptions selectedWebDriverOption;
    private final String operatingSystem = System.getProperty("os.name").toUpperCase();
    private final String systemArchitecture = System.getProperty("os.arch");
    private final boolean headlessMode = Boolean.getBoolean ("headless");

    public AutomationFactory() {
        DriverOptions webDriverOption = CHROME;
        String browser = System.getProperty("browserType", webDriverOption.toString().toUpperCase());
        try {
            webDriverOption = DriverOptions.valueOf(browser.toUpperCase());
        } catch (IllegalArgumentException ignored) {
            System.err.println("Unknown driver specified, defaulting to '" + webDriverOption + "'...");
        } catch (NullPointerException ignored) {
            System.err.println("No driver specified, defaulting to '" + webDriverOption + "'...");
        }
        selectedWebDriverOption = webDriverOption;
    }

    public WebDriver instantiateWebDriver(DriverOptions driverOption) {
        System.out.println(" ");
        System.out.println("Current Operating System: " + operatingSystem);
        System.out.println("Current Architecture: " + systemArchitecture);
        System.out.println("Browser Selected: " + selectedWebDriverOption);
        System.out.println ("Headless Mode: " + headlessMode);
        System.out.println(" ");

        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        webDriver = driverOption.getWebDriverObject(desiredCapabilities);

        return webDriver;
    }

    public WebDriver getDriver() {
        return instantiateWebDriver(selectedWebDriverOption);
    }

    public void quitDriver() {
        webDriver.quit();
    }
}
