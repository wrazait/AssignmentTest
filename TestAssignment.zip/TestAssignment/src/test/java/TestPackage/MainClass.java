package TestPackage;

import PageObjects.UiFactory;
import Utilities.AutomationFactory;
import Utilities.ReadWriteExcel;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class MainClass
{
    public static WebDriver webDriver;
    protected AutomationFactory automationWebDriver;
    public XSSFSheet sheet;
    protected ReadWriteExcel readwrite;
    protected UiFactory obj;
    protected Properties properties;

    @BeforeSuite
    public void applicationOpen() throws IOException
    {
        automationWebDriver = new AutomationFactory();
        webDriver = automationWebDriver.getDriver();
        System.out.println("====Application open successfully in browser======");
        readwrite=new ReadWriteExcel(sheet);
        properties = System.getProperties();
        try {
            properties.load(new FileInputStream("src/test/resources/test.properties"));
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }
    @BeforeClass
    public void setUp()
    {
        automationWebDriver = new AutomationFactory();
        webDriver = automationWebDriver.getDriver();
        webDriver.get(System.getProperty("baseUrl"));
        obj = new UiFactory(webDriver);
    }

    @BeforeMethod
    public void homePage()
    {
        webDriver.get("https://www.etsy.com/?ref=lgo");
    }
    @AfterSuite
    public void tearDown() throws InterruptedException
    {
        System.out.println("====Browser closed successfully======");
        automationWebDriver.quitDriver();
    }
}
