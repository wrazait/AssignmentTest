package TestPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class CartPage extends MainClass
{
    @Test
    public void testCase()
    {
        webDriver.findElement(By.id("side-nav-category-link-10936")).click();
        webDriver.findElement(By.id("side-nav-category-link-10924")).click();
        webDriver.findElement(By.id("catnav-l4-10926")).click();
        webDriver.findElement(By.xpath("//img[@alt='Minimalist']")).click();
        webDriver.findElement(By.xpath("//img[@alt='Minimalist Dress FRENCH. Cocktail Dress For Women in Deep Blue. Handmade Dress. Midi Casual Dress.']")).click();
        // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | win_ser_2 | ]]
        webDriver.findElement(By.id("variation-selector-0")).click();
        new Select(webDriver.findElement(By.id("variation-selector-0"))).selectByVisibleText("Deep blue");
        webDriver.findElement(By.id("variation-selector-1")).click();
        new Select(webDriver.findElement(By.id("variation-selector-1"))).selectByVisibleText("XS US Women's");
        webDriver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Etsy'])[1]/following::*[name()='svg'][1]")).click();
        webDriver.findElement(By.xpath("//main[@id='content']/div/div[3]")).click();
        webDriver.findElement(By.xpath("//main[@id='content']/div/div[3]/div/div/div/div/a/div/div/div/div/div/div")).click();
        // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | win_ser_3 | ]]
        webDriver.findElement(By.id("variation-selector-0")).click();
        new Select(webDriver.findElement(By.id("variation-selector-0"))).selectByVisibleText("S");
        webDriver.findElement(By.id("variation-selector-1")).click();
        new Select(webDriver.findElement(By.id("variation-selector-1"))).selectByVisibleText("Enamel blue");
        webDriver.findElement(By.id("listing-page-personalization-textarea")).click();
        webDriver.findElement(By.id("listing-page-personalization-textarea")).clear();
        webDriver.findElement(By.id("listing-page-personalization-textarea")).sendKeys("Test");
        webDriver.findElement(By.xpath("//div[@id='listing-page-cart']/div[3]/div/div[2]/div[2]/form/div/button")).click();
        webDriver.findElement(By.linkText("2")).click();
        // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | win_ser_2 | ]]
        // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | win_ser_3 | ]]
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div/div/div/ul/li/ul/li/div/div[2]/div/div[2]/div/div/div/div/div/select")).click();
        new Select(webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div/div/div/ul/li/ul/li/div/div[2]/div/div[2]/div/div/div/div/div/select"))).selectByVisibleText("2");
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div/div/div/ul/li/ul/li/div/div[2]/div/div[2]/div/div/div/div/div/select/option[2]")).click();
        webDriver.findElement(By.name("message_to_seller")).click();
        webDriver.findElement(By.name("message_to_seller")).clear();
        webDriver.findElement(By.name("message_to_seller")).sendKeys("Test");
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div/div/div/ul/li/div[4]/div[2]/div/div")).click();
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div/div/div/ul/li/div[3]/div/fieldset/div/label")).click();
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div[2]/div/div/ul/li/ul/li/div/div[2]/div/div[2]/div/div/div/div/div/select")).click();
        new Select(webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div[2]/div/div/ul/li/ul/li/div/div[2]/div/div[2]/div/div/div/div/div/select"))).selectByVisibleText("5");
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div[2]/div/div/ul/li/ul/li/div/div[2]/div/div[2]/div/div/div/div/div/select/option[5]")).click();
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div[2]/div/div/ul/li/ul/li/div/div[2]/div/div/div[2]/div/a")).click();
        webDriver.findElement(By.id("wt-cart-select-")).click();
        new Select(webDriver.findElement(By.id("wt-cart-select-"))).selectByVisibleText("6 1/4 US");
        webDriver.findElement(By.xpath("//div[@id='multi-shop-cart-list']/div[2]/div/div/ul/li/ul/li/div/div[2]/div/div/div[4]/ul/li[2]/a/span")).click();
    }
}
