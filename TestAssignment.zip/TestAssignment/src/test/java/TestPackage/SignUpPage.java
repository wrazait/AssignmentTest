package TestPackage;

import org.testng.annotations.*;

public class SignUpPage extends MainClass
{
    @Test
    public void signUpWithGmail()
    {
        obj.clickSignButton();
        obj.regisButton();
        obj.regisGmailButton();
    }

}

