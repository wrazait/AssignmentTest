package TestPackage;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class LoginPage extends MainClass
{
    String emailFieldValue;
    String passFieldValue;
    @Test
    public void testCaseEmptyData()
    {
        obj.clickSignButton();
        obj.emailField("");
        obj.passwordField("");
        obj.clickSubmitButton();
        emailFieldValue=obj.getEmailFieldValue();
        passFieldValue=obj.getPassFieldValue();
        if(emailFieldValue == System.getProperty("blank_email_field_error") && passFieldValue== System.getProperty("blank_pass_field_error")) {
            System.out.println("PASS");
        }
        else
            System.out.println("FAIL");
    }

    @Test
    public void testCaseWrongData()
    {
        obj.clickSignButton();
        obj.emailField(System.getProperty("wrongemial"));
        obj.passwordField("wrongpass");
        obj.clickSubmitButton();
        emailFieldValue=obj.getEmailFieldValue();
        passFieldValue=obj.getPassFieldValue();
        if(emailFieldValue == System.getProperty("invalid_email_address_error") && passFieldValue == System.getProperty("wrong_pass_error")) {
            System.out.println("PASS");
        }
        else
            System.out.println("FAIL");
    }
    @Test
    public void testCaseValidData()
    {
        obj.clickSignButton();
        obj.emailField("useremail");
        obj.passwordField("userpassword");
        obj.clickSubmitButton();
    }
}
