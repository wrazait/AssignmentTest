package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UiFactory
{
    WebDriver webDriver;

    public  UiFactory(WebDriver driver)
    {
        this.webDriver = driver;
        PageFactory.initElements(webDriver, this);
    }
    //Login UI Elements
    @FindBy(how = How.XPATH,using = ("//header[@id='gnav-header-inner']/div[4]/nav/ul/li/button"))
    WebElement signInButton;

    @FindBy(how = How.ID,using = ("join_neu_password_field"))
    WebElement passwordField;

    @FindBy(how = How.ID,using = ("join_neu_email_field"))
    WebElement emailField;

    @FindBy(how = How.NAME,using = ("submit_attempt"))
    WebElement submitButton;

    public void clickSignButton()
    {
        signInButton.click();
    }
    public void clickSubmitButton()
    {
        submitButton.click();
    }
    public void emailField(String value)
    {
        emailField.click();
        emailField.sendKeys(value);
    }
    public void passwordField(String value)
    {
        passwordField.click();
        passwordField.sendKeys(value);
    }
    public String getEmailFieldValue()
    {
        String value=emailField.getText();
        return value;
    }
    public String getPassFieldValue()
    {
        String value=passwordField.getText();
        return value;
    }
    //SignUp UI Elements
    @FindBy(how = How.CSS,using = ("button.inline-overlay-trigger:nth-child(2)"))
    WebElement registerButton;

    @FindBy(how = How.CSS,using = ("button.inline-overlay-trigger:nth-child(2)"))
    WebElement registerGmailButton;

    public void regisButton()
    {
        registerButton.click();
    }
    public void regisGmailButton()
    {
        registerGmailButton.click();
    }
    //Cart UI Elements
}
